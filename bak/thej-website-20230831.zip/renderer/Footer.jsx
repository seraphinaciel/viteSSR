export { Footer };

function Footer() {
  return (
    <footer>
      <h2 className="bg-green-500 text-center p-3">the end</h2>
    </footer>
  );
}
