import styles from "./Main.module.css";

// import Text from "#root/components/Text";
import Video from "#root/components/Video/Video";
import { Text } from "../../components/Text";

export const title = "🥰 Main",
	description = "this is a Main page.";

function Page() {
	return (
		<>
			<h1 className={styles.name}>Main</h1>
			<Video id="smaller" src="https://www.w3schools.com/tags/movie.mp4">
				<div className={styles.main_txt}>
					<Text>{"Our latest"}</Text>
					<Text>{"SCROLL"}</Text>
				</div>
			</Video>
		</>
	);
}
export { Page };
