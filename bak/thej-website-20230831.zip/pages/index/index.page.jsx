import { Text, Title } from "#root/components/Text";
import WSGTemplate from "../../components/WSGTemplate";

// head의 title, meta 내용
export const documentProps = {
	title: "😁 main",
	description: `this is a main page.`,
};

function Page() {
	return (
		<div>
			<Title>{["We create designs", "to inspire people", "around the world"]}</Title>
			<Text>{"This page is:"}</Text>
			<WSGTemplate />
		</div>
	);
}

export { Page };
